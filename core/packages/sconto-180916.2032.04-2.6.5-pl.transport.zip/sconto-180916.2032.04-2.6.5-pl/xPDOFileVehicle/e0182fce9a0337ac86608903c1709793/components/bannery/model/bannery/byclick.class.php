<?php
class byClick extends xPDOSimpleObject {}