<?php
require_once (dirname(dirname(__FILE__)) . '/byposition.class.php');
class byPosition_mysql extends byPosition {}