<?php
require_once (dirname(dirname(__FILE__)) . '/byad.class.php');
class byAd_mysql extends byAd {}