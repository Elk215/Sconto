<?php
/**
 * Custom English Lexicon Entries for Collections
 *
 * @package collections
 * @subpackage lexicon
 */