--------------------
Extra: Ace
--------------------
Since: March 29th, 2012
Author: Danil Kostin <danya.postfactum@gmail.com>
License: GNU GPLv2 (or later at your option)

Integrates Ace Code Editor into MODx Revolution.

Press Ctrl+Alt+H to see all available shortcuts.