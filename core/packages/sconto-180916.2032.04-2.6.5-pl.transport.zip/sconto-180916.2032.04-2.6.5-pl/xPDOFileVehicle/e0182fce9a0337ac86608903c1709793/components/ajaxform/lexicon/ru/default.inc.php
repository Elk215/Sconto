<?php

$_lang['ajaxform'] = 'AjaxForm';

$_lang['af_message_close_all'] = 'закрыть все';
$_lang['af_submit'] = 'Отправить';
$_lang['af_reset'] = 'Очистить';

$_lang['af_label_name'] = 'Имя';
$_lang['af_label_email'] = 'E-mail';
$_lang['af_label_message'] = 'Сообщение';

$_lang['af_err_action_ns'] = 'Не указан ключ формы (action).';
$_lang['af_err_action_nf'] = 'Не могу найти указанный ключ формы (action).';
$_lang['af_err_chunk_ns'] = 'Не указан чанк для обработки формы.';
$_lang['af_err_chunk_nf'] = 'Не могу найти указанный чанк "[[+name]]" с формой.';
$_lang['af_err_snippet_ns'] = 'Не указан сниппет для обработки формы.';
$_lang['af_err_snippet_nf'] = 'Не могу найти указанный сниппет "[[+name]]" для обработки формы.';
$_lang['af_err_has_errors'] = 'Форма содержит ошибки';
$_lang['af_success_submit'] = 'Форма успешно отправлена';
