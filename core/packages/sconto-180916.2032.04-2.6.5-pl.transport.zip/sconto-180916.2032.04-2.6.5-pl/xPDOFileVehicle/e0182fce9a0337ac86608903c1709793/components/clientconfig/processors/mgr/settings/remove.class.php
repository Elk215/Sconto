<?php
/**
 * @package ClientConfig
 */
class cgSettingRemoveProcessor extends modObjectRemoveProcessor {
    public $classKey = 'cgSetting';
    public $objectType = 'cgSetting';
}
return 'cgSettingRemoveProcessor';
