<?php
$_lang['error_log'] = 'Error log';
$_lang['cel_refresh'] = 'Refresh';
$_lang['cel_clear'] = 'Clear';
$_lang['cel_close'] = 'Close';
$_lang['cel_copy'] = 'Make a copy';
$_lang['errors_title'] = 'Open the error log in a new window';
$_lang['error_log_last_lines'] = 'The last [[+last]] lines.';
$_lang['error_log_download'] = 'Download Error Log ([[+size]]Mb)';
$_lang['error_log_too_large'] = 'The error log at <em>[[+name]]</em> is too large to be viewed. You can download it via the button below.';
$_lang['error_log_email_subject'] = 'Detected some errors on the site';
$_lang['error_log_email_body'] = 'Check the system error log on the site "[[+siteName]]".';