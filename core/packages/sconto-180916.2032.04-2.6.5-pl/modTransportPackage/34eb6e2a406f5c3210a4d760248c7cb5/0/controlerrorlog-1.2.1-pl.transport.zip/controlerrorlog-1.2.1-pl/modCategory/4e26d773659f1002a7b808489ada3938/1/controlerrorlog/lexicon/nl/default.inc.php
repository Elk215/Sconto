<?php
$_lang['error_log'] = 'Foutlog';
$_lang['cel_refresh'] = 'Verversen';
$_lang['cel_clear'] = 'Legen';
$_lang['cel_close'] = 'Sluiten';
$_lang['cel_copy'] = 'Make a copy';
$_lang['errors_title'] = 'Open foutlog in een nieuw venster';
$_lang['error_log_last_lines'] = 'De laatste [[+last]] regels.';
$_lang['error_log_download'] = 'Download foutlog ([[+size]]Mb)';
$_lang['error_log_too_large'] = 'Het foutlog op <em>[[+name]]</em> is te groot om weer te geven. Download het foutlog via onderstaande knop.';
$_lang['error_log_email_subject'] = 'Er zijn fouten in het foutlog weggeschreven';
$_lang['error_log_email_body'] = 'Bekijk de foutlog ("[[+siteName]]").';
