<?php
$_lang['error_log'] = 'Журнал ошибок';
$_lang['cel_refresh'] = 'Обновить';
$_lang['cel_clear'] = 'Очистить';
$_lang['cel_close'] = 'Закрыть';
$_lang['cel_copy'] = 'Сделать копию';
$_lang['errors_title'] = 'Открыть журнал ошибок в новом окне';
$_lang['error_log_last_lines'] = 'Последние [[+last]] строк.';
$_lang['error_log_download'] = 'Скачать журнал ошибок ([[+size]]Mb)';
$_lang['error_log_too_large'] = 'Журнал ошибок <em>[[+name]]</em> слишком большой для просмотра. Вы можете скачать журнал, нажав на кнопку ниже.';
$_lang['error_log_email_subject'] = 'Ошибка на сайте';
$_lang['error_log_email_body'] = 'На сайте "[[+siteName]]" обнаружена ошибка. Проверьте журнал ошибок.';