<?php
$_lang['area_controlerrorlog.main'] = 'Основные';

$_lang['setting_controlerrorlog.last_lines'] = 'Количество строчек';
$_lang['setting_controlerrorlog.last_lines_desc'] = 'Показывает указанное количество последних строчек, когда журнал слишком большой для отображения.';
$_lang['setting_controlerrorlog.refresh_freq'] = 'Частота обновления (сек)';
$_lang['setting_controlerrorlog.refresh_freq_desc'] = 'Частота обновления журнала ошибок в секундах.';
$_lang['setting_controlerrorlog.auto_refresh'] = 'Обновлять автоматически';
$_lang['setting_controlerrorlog.auto_refresh_desc'] = 'Включает автоматическую проверку состояния журнала ошибок с указанной частотой.';
$_lang['setting_controlerrorlog.control_frontend'] = 'Уведомлять об ошибках';
$_lang['setting_controlerrorlog.control_frontend_desc'] = 'Контролировать журнал ошибок и уведомлять об изменениях.';
$_lang['setting_controlerrorlog.admin_email'] = 'Email для уведомления';
$_lang['setting_controlerrorlog.admin_email_desc'] = 'Укажите элекстронную почту администратора для уведомления об ошибках.';